from django.apps import AppConfig


class CoocrConfig(AppConfig):
    name = 'atomom'
